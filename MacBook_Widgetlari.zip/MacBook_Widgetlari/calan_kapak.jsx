// ŞU AN ÇALAN — albüm kapağı arka planı bulanık dolduruyor, ilerleme halkası, ekolayzır (Spotify, API yok, yerel)
import { css } from "uebersicht";
export const refreshFrequency = 2000;
export const command = `osascript -e '
tell application "System Events" to set sp to (name of processes) contains "Spotify"
if sp then
  tell application "Spotify"
    if player state is playing then return (name of current track) & "|" & (artist of current track) & "|" & (player position as integer) & "|" & ((duration of current track) / 1000 as integer) & "|" & (artwork url of current track)
  end tell
end if
return ""
'`;
export const className = css`position: absolute; bottom: 36px; left: 28px; width: 560px; height: 150px; padding: 0; border-radius: 22px; overflow: hidden; color: #fff; font-family: -apple-system, "SF Pro Display", "Inter", sans-serif; border: 1px solid rgba(255,255,255,0.16); box-shadow: 0 18px 50px rgba(0,0,0,0.45); background: rgba(14,18,34,0.7);`;
const mmss = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
export const render = ({ output }) => {
  const o = (output || "").trim();
  if (!o) return (
    <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 22px", height: "100%", opacity: .7 }}>
      <div style={{ fontSize: 30 }}>🎧</div><div style={{ fontSize: 15 }}>Spotify'da bir şey çal, burası canlanır</div>
    </div>
  );
  const [ad, sanatci, poz, sure, art] = o.split("|"); const p = Math.min(1, Number(poz) / Math.max(1, Number(sure)));
  const R = 48, C = 2 * Math.PI * R;
  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      <style>{`@keyframes eq{0%,100%{transform:scaleY(.3)}50%{transform:scaleY(1)}}`}</style>
      <div style={{ position: "absolute", inset: -40, backgroundImage: `url(${art})`, backgroundSize: "cover", backgroundPosition: "center", filter: "blur(34px) saturate(1.4) brightness(.55)" }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(10,12,24,.35), rgba(10,12,24,.75))" }} />
      <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 20, padding: "0 22px", height: "100%" }}>
        <div style={{ position: "relative", width: 110, height: 110, flex: "none" }}>
          <svg width="110" height="110" viewBox="0 0 110 110" style={{ position: "absolute", inset: 0 }}>
            <circle cx="55" cy="55" r={R} fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="4" />
            <circle cx="55" cy="55" r={R} fill="none" stroke="#4ade80" strokeWidth="4" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - p)} transform="rotate(-90 55 55)" style={{ transition: "stroke-dashoffset 2s linear" }} />
          </svg>
          <img src={art} style={{ position: "absolute", left: 11, top: 11, width: 88, height: 88, borderRadius: 44, objectFit: "cover", boxShadow: "0 8px 24px rgba(0,0,0,.5)" }} />
        </div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 11, letterSpacing: 1.5, opacity: .7, textTransform: "uppercase" }}>Şu an çalan · Spotify</div>
          <div style={{ fontSize: 22, fontWeight: 800, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginTop: 2 }}>{ad}</div>
          <div style={{ fontSize: 15, opacity: .85, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{sanatci}</div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, opacity: .65, marginTop: 8 }}><span>{mmss(Number(poz))}</span><span>{mmss(Number(sure))}</span></div>
        </div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 44, flex: "none" }}>
          {[0, 1, 2, 3, 4].map(i => <div key={i} style={{ width: 6, height: 44, borderRadius: 3, background: "#4ade80", transformOrigin: "bottom", animation: `eq ${0.6 + i * 0.13}s ease-in-out ${i * 0.08}s infinite` }} />)}
        </div>
      </div>
    </div>
  );
};
