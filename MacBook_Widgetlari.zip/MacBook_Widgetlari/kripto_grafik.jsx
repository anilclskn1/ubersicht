// BİTCOİN GRAFİĞİ — kendini çizen 7 günlük çizgi, canlı fiyat sayacı (CoinGecko, ücretsiz, anahtar yok)
import { css } from "uebersicht";
export const command = `curl -sL "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=7"`;
export const refreshFrequency = 2 * 60 * 1000;
export const className = css`position: absolute; top: 540px; right: 28px; width: 380px; height: 236px; padding: 0; border-radius: 22px; overflow: hidden; color: #fff; background: rgba(14, 18, 34, 0.6); backdrop-filter: blur(22px); -webkit-backdrop-filter: blur(22px); border: 1px solid rgba(255,255,255,0.14); box-shadow: 0 18px 50px rgba(0,0,0,0.4);`;
// KRİPTO GRAFİĞİ — çizim çekirdeği (kendini çizen 7 günlük çizgi)
var KR = {
  prices: null, reveal: 0, lastT: 0, shown: 0,
  set: function(arr){ this.prices=arr; this.reveal=0; },
  draw: function(cv){
    var ctx=cv.getContext("2d"), dpr=cv.__dpr||1, W=cv.__w||cv.width, H=cv.__h||cv.height; ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,W,H);
    var P=this.prices; if(!P||P.length<2){ ctx.fillStyle="rgba(255,255,255,0.6)"; ctx.font="500 14px -apple-system, Inter, sans-serif"; ctx.fillText("Grafik yükleniyor…",16,H/2); return; }
    var dt=this.lastT?Math.min(0.05,(Date.now()-this.lastT)/1000):0.016; this.lastT=Date.now();
    this.reveal=Math.min(1,this.reveal+dt*0.7);
    var pad={l:14,r:14,t:70,b:22}; var ys=P.map(function(p){return p[1];}); var mn=Math.min.apply(null,ys), mx=Math.max.apply(null,ys); var rng=(mx-mn)||1;
    var n=P.length, k=Math.max(2,Math.floor(n*this.reveal));
    var X=function(i){ return pad.l+(W-pad.l-pad.r)*i/(n-1); }, Y=function(v){ return pad.t+(H-pad.t-pad.b)*(1-(v-mn)/rng); };
    var up=ys[ys.length-1]>=ys[0]; var col=up?"74,222,128":"248,113,113";
    // alan
    ctx.beginPath(); ctx.moveTo(X(0),Y(ys[0])); for(var i=1;i<k;i++) ctx.lineTo(X(i),Y(ys[i])); ctx.lineTo(X(k-1),H-pad.b); ctx.lineTo(X(0),H-pad.b); ctx.closePath();
    var ag=ctx.createLinearGradient(0,pad.t,0,H); ag.addColorStop(0,"rgba("+col+",0.35)"); ag.addColorStop(1,"rgba("+col+",0)"); ctx.fillStyle=ag; ctx.fill();
    // çizgi
    ctx.strokeStyle="rgb("+col+")"; ctx.lineWidth=2.4; ctx.lineJoin="round"; ctx.beginPath(); ctx.moveTo(X(0),Y(ys[0])); for(var j=1;j<k;j++) ctx.lineTo(X(j),Y(ys[j])); ctx.stroke();
    // uç nokta
    var ex=X(k-1), ey=Y(ys[k-1]); var pulse=0.5+0.5*Math.sin(Date.now()/300); ctx.fillStyle="rgba("+col+","+(0.25*(1-pulse))+")"; ctx.beginPath(); ctx.arc(ex,ey,8+10*pulse,0,7); ctx.fill(); ctx.fillStyle="#fff"; ctx.beginPath(); ctx.arc(ex,ey,3.5,0,7); ctx.fill();
    // başlık + fiyat (sayaç)
    var target=ys[ys.length-1]; this.shown += (target-this.shown)*Math.min(1,dt*4);
    var chg=(ys[ys.length-1]-ys[0])/ys[0]*100;
    ctx.fillStyle="rgba(255,255,255,0.7)"; ctx.font="600 12px -apple-system, Inter, sans-serif"; ctx.fillText("BITCOIN · 7 GÜN",16,22);
    ctx.fillStyle="#fff"; ctx.font="700 30px -apple-system, Inter, sans-serif"; ctx.fillText("$"+Math.round(this.shown).toLocaleString("en-US"),16,54);
    var ct=(chg>=0?"▲ +":"▼ ")+chg.toFixed(2)+"%"; ctx.font="600 14px -apple-system, Inter, sans-serif"; var tw=ctx.measureText(ct).width; ctx.fillStyle="rgba("+col+",0.18)"; ctx.fillRect(W-pad.r-tw-20,34,tw+20,24); ctx.fillStyle="rgb("+col+")"; ctx.fillText(ct,W-pad.r-tw-10,51);
    // alt tarihler
    ctx.fillStyle="rgba(255,255,255,0.45)"; ctx.font="500 10px -apple-system, Inter, sans-serif"; var d0=new Date(P[0][0]), d1=new Date(P[n-1][0]); var f=function(d){return d.getDate()+" "+["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"][d.getMonth()];};
    ctx.fillText(f(d0),pad.l,H-8); var t1=f(d1); ctx.fillText(t1,W-pad.r-ctx.measureText(t1).width,H-8);
  }
};

export const initialState = { n: 0 };
export const updateState = (ev, prev) => { try { KR.set(JSON.parse(ev.output).prices); } catch (e) {} return { n: (prev.n || 0) + 1 }; };
const DRAW = (cv) => KR.draw(cv);
const start = (cv) => {
  if (!cv || cv.__run) return; cv.__run = true;
  const fit = () => { const r = cv.getBoundingClientRect(); const dpr = window.devicePixelRatio || 1;
    cv.__w = Math.max(50, r.width); cv.__h = Math.max(50, r.height); cv.__dpr = dpr; cv.width = cv.__w * dpr; cv.height = cv.__h * dpr; };
  fit(); window.addEventListener("resize", fit);
  (function loop() { try { DRAW(cv); } catch (e) {} requestAnimationFrame(loop); })();
};

export const render = () => <canvas ref={start} style={{ width: "100%", height: "100%", display: "block" }} />;
