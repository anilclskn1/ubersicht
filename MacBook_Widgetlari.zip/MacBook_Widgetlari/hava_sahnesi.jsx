// HAVA SAHNESİ — gerçek havayı canlandıran gökyüzü bandı (Open-Meteo, ücretsiz, anahtar yok)
// Şehir için LAT/LON/SEHIR'i değiştir. Yağmur yağar, kar düşer, bulutlar süzülür, gece yıldızlar çıkar, fırtınada şimşek çakar.
import { css } from "uebersicht";
// >>> ŞEHRİNİ YAZ: koordinatı Google Maps'te şehrine sağ tıklayıp kopyalayabilirsin (örnek: İstanbul merkez).
const LAT = 41.01, LON = 28.98, SEHIR = "İstanbul";
export const command = `curl -sL "https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset&timezone=auto"`;
export const refreshFrequency = 10 * 60 * 1000;
export const className = css`position: absolute; top: 28px; left: 28px; right: 28px; height: 240px; border-radius: 24px; overflow: hidden; border: 1px solid rgba(255,255,255,0.16); box-shadow: 0 18px 50px rgba(0,0,0,0.4);`;
// HAVA SAHNESİ — çizim çekirdeği (jsx ve önizleme aynı kodu kullanır)
var HS = {
  data: null, stars: null, clouds: null, drops: null, flakes: null, flash: 0, lastT: 0,
  KOD: {0:"Açık",1:"Az bulutlu",2:"Parçalı bulutlu",3:"Kapalı",45:"Sisli",48:"Sisli",51:"Çiseleme",53:"Çiseleme",55:"Çiseleme",61:"Hafif yağmur",63:"Yağmur",65:"Kuvvetli yağmur",71:"Hafif kar",73:"Kar",75:"Yoğun kar",80:"Sağanak",81:"Sağanak",82:"Şiddetli sağanak",95:"Fırtına",96:"Dolu",99:"Dolu"},
  rnd: function(seed){ var s=seed; return function(){ s=(s*16807)%2147483647; return (s-1)/2147483646; }; },
  init: function(W,H){
    var r=this.rnd(42);
    this.stars=[]; for(var i=0;i<140;i++) this.stars.push([r()*W, r()*H*0.75, 0.6+r()*1.4, r()*6.28]);
    this.clouds=[]; for(var j=0;j<9;j++) this.clouds.push({x:r()*W, y:30+r()*(H*0.45), s:0.7+r()*0.9, v:6+r()*10, o:0.5+r()*0.5});
    this.drops=[]; for(var k=0;k<220;k++) this.drops.push([r()*W, r()*H, 300+r()*260, 10+r()*14]);
    this.flakes=[]; for(var m=0;m<120;m++) this.flakes.push([r()*W, r()*H, 18+r()*30, 1.2+r()*2.2, r()*6.28]);
  },
  // gün evresi: 0 gece, 1 gündüz; sunrise/sunset "YYYY-MM-DDTHH:MM"
  phase: function(d, now){
    if(!d||!d.daily) return 0.5;
    var hm=function(s){ return parseInt(s.slice(11,13))*60+parseInt(s.slice(14,16)); };
    var sr=hm(d.daily.sunrise[0]), ss=hm(d.daily.sunset[0]); var t=now.getHours()*60+now.getMinutes();
    var f=function(x){ return Math.max(0,Math.min(1,x)); };
    if(t<sr-60||t>ss+60) return 0;
    if(t<sr+40) return f((t-(sr-60))/100)*0.55;              // şafak
    if(t>ss-40) return f(((ss+60)-t)/100)*0.55;              // akşam
    return 1;
  },
  draw: function(cv, now){
    var ctx=cv.getContext("2d"), dpr=cv.__dpr||1, W=cv.__w||cv.width, H=cv.__h||cv.height; ctx.setTransform(dpr,0,0,dpr,0,0); if(!this.stars) this.init(W,H);
    var d=this.data, code=d&&d.current?d.current.weather_code:2, p=this.phase(d, now||new Date());
    var dt=this.lastT? Math.min(0.05,(Date.now()-this.lastT)/1000):0.016; this.lastT=Date.now();
    var rain=(code>=51&&code<=67)||(code>=80&&code<=82)||code>=95, snow=code>=71&&code<=77, storm=code>=95, fog=code===45||code===48;
    var cloudy= code===3||rain||snow||fog ? 1 : code===2 ? 0.6 : code===1 ? 0.3 : 0.1;
    // gökyüzü
    var g=ctx.createLinearGradient(0,0,0,H);
    var dusk=p>0&&p<0.6;
    if(p>=0.6){ g.addColorStop(0,cloudy>0.9?"#5b6b86":"#2e6fd8"); g.addColorStop(1,cloudy>0.9?"#8d99ad":"#8ec5ff"); }
    else if(dusk){ g.addColorStop(0,"#1b1a40"); g.addColorStop(0.55,"#7a3b6e"); g.addColorStop(1,"#f28c5a"); }
    else { g.addColorStop(0,"#05070f"); g.addColorStop(1,"#141b38"); }
    ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
    // yıldızlar
    if(p<0.6){ var tw=Date.now()/700; for(var i=0;i<this.stars.length;i++){ var s=this.stars[i]; var a=(0.35+0.65*Math.abs(Math.sin(tw+s[3])))*(1-p/0.6)*(1-cloudy*0.7); ctx.fillStyle="rgba(255,255,255,"+a+")"; ctx.beginPath(); ctx.arc(s[0],s[1],s[2],0,7); ctx.fill(); } }
    // güneş / ay
    if(p>=0.6 && cloudy<0.9){ var sx=W*0.78, sy=H*0.42; var sg=ctx.createRadialGradient(sx,sy,10,sx,sy,120); sg.addColorStop(0,"rgba(255,245,200,0.95)"); sg.addColorStop(0.25,"rgba(255,220,120,0.55)"); sg.addColorStop(1,"rgba(255,200,80,0)"); ctx.fillStyle=sg; ctx.fillRect(sx-130,sy-130,260,260); ctx.fillStyle="#fff6c8"; ctx.beginPath(); ctx.arc(sx,sy,26,0,7); ctx.fill(); }
    if(p<0.3){ var mx=W*0.8, my=H*0.36; ctx.fillStyle="rgba(240,240,255,0.95)"; ctx.beginPath(); ctx.arc(mx,my,22,0,7); ctx.fill(); ctx.fillStyle= p<0.15?"#05070f":"#1b1a40"; ctx.beginPath(); ctx.arc(mx+9,my-5,19,0,7); ctx.fill(); }
    // bulutlar
    for(var c=0;c<this.clouds.length;c++){ var cl=this.clouds[c]; if(c/this.clouds.length>cloudy) continue; cl.x+=cl.v*dt*cl.s; if(cl.x>W+180) cl.x=-180;
      var ca=cl.o*(p>=0.6?0.95:0.55)*(rain?0.9:0.8); var col=rain||code===3?"110,118,135":"255,255,255";
      ctx.fillStyle="rgba("+col+","+ca+")"; var r0=28*cl.s; ctx.beginPath(); ctx.arc(cl.x,cl.y,r0,0,7); ctx.arc(cl.x+r0*1.1,cl.y-r0*0.4,r0*1.25,0,7); ctx.arc(cl.x+r0*2.4,cl.y,r0*0.95,0,7); ctx.arc(cl.x+r0*1.3,cl.y+r0*0.45,r0*1.1,0,7); ctx.fill(); }
    // sis
    if(fog){ for(var f=0;f<4;f++){ var fy=H*0.35+f*H*0.17; var fg=ctx.createLinearGradient(0,fy-30,0,fy+30); fg.addColorStop(0,"rgba(220,225,235,0)"); fg.addColorStop(0.5,"rgba(220,225,235,0.35)"); fg.addColorStop(1,"rgba(220,225,235,0)"); ctx.fillStyle=fg; ctx.fillRect(0,fy-30,W,60);} }
    // yağmur
    if(rain){ ctx.strokeStyle="rgba(200,220,255,0.55)"; ctx.lineWidth=1.3; ctx.beginPath(); for(var q=0;q<this.drops.length;q++){ var dr=this.drops[q]; dr[1]+=dr[2]*dt; dr[0]-=dr[2]*dt*0.18; if(dr[1]>H){dr[1]=-20; dr[0]=Math.random()*W+40;} ctx.moveTo(dr[0],dr[1]); ctx.lineTo(dr[0]-dr[3]*0.18,dr[1]-dr[3]); } ctx.stroke(); }
    // kar
    if(snow){ ctx.fillStyle="rgba(255,255,255,0.9)"; for(var z=0;z<this.flakes.length;z++){ var fl=this.flakes[z]; fl[1]+=fl[2]*dt; fl[4]+=dt; fl[0]+=Math.sin(fl[4])*0.5; if(fl[1]>H){fl[1]=-10; fl[0]=Math.random()*W;} ctx.beginPath(); ctx.arc(fl[0],fl[1],fl[3],0,7); ctx.fill(); } }
    // şimşek
    if(storm){ if(Math.random()<0.012) this.flash=1; if(this.flash>0){ ctx.fillStyle="rgba(255,255,255,"+(this.flash*0.7)+")"; ctx.fillRect(0,0,W,H); this.flash-=dt*4; } }
    // yazı
    if(d&&d.current){ var cur=d.current; ctx.fillStyle="rgba(255,255,255,0.92)"; ctx.font="600 15px -apple-system, Inter, sans-serif"; ctx.fillText((this.sehir||"İSTANBUL").toUpperCase(), 28, 40);
      ctx.font="700 64px -apple-system, Inter, sans-serif"; ctx.fillText(Math.round(cur.temperature_2m)+"°", 26, 108);
      ctx.font="500 17px -apple-system, Inter, sans-serif"; ctx.fillStyle="rgba(255,255,255,0.8)"; ctx.fillText((this.KOD[code]||"")+"  ·  hissedilen "+Math.round(cur.apparent_temperature)+"°", 28, 140);
      ctx.font="500 13px -apple-system, Inter, sans-serif"; ctx.fillStyle="rgba(255,255,255,0.65)"; var dd=d.daily; ctx.fillText("↑ "+Math.round(dd.temperature_2m_max[0])+"°   ↓ "+Math.round(dd.temperature_2m_min[0])+"°   💧 "+dd.precipitation_probability_max[0]+"%   🌅 "+dd.sunrise[0].slice(11,16)+"   🌇 "+dd.sunset[0].slice(11,16), 28, H-22); }
    // alt kenar yumuşatma
    var vg=ctx.createLinearGradient(0,H-40,0,H); vg.addColorStop(0,"rgba(0,0,0,0)"); vg.addColorStop(1,"rgba(0,0,0,0.25)"); ctx.fillStyle=vg; ctx.fillRect(0,H-40,W,40);
  }
};

HS.sehir = SEHIR;
export const initialState = { n: 0 };
export const updateState = (ev, prev) => { try { HS.data = JSON.parse(ev.output); } catch (e) {} return { n: (prev.n || 0) + 1 }; };
const DRAW = (cv) => HS.draw(cv, new Date());
const start = (cv) => {
  if (!cv || cv.__run) return; cv.__run = true;
  const fit = () => { const r = cv.getBoundingClientRect(); const dpr = window.devicePixelRatio || 1;
    cv.__w = Math.max(50, r.width); cv.__h = Math.max(50, r.height); cv.__dpr = dpr; cv.width = cv.__w * dpr; cv.height = cv.__h * dpr; };
  fit(); window.addEventListener("resize", fit);
  (function loop() { try { DRAW(cv); } catch (e) {} requestAnimationFrame(loop); })();
};

export const render = () => <canvas ref={start} style={{ width: "100%", height: "100%", display: "block" }} />;
