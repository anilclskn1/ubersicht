// KİNETİK SAAT — dev saat, kayan saniye halkası, Türkçe tarih ve selamlama (API yok)
import { css } from "uebersicht";
// Übersicht yenilemeyi komutun çalışmasına bağlar; komut yoksa render bir kez çalışır ve donar.
// Bu yüzden her saniye çok ucuz bir komut çalıştırıyoruz: çıktısı her saniye değişir → yeniden çizim.
export const command = "date +%s";
export const refreshFrequency = 1000;
export const className = css`position: absolute; top: 300px; right: 28px; width: 380px; padding: 16px 18px; border-radius: 22px; color: #fff; font-family: -apple-system, "SF Pro Display", "Inter", sans-serif; background: rgba(14, 18, 34, 0.6); backdrop-filter: blur(22px); -webkit-backdrop-filter: blur(22px); border: 1px solid rgba(255,255,255,0.14); box-shadow: 0 18px 50px rgba(0,0,0,0.4); padding: 20px 22px;`;
const AD = ""; // >>> ADINI YAZ (örn. "Ayşe") — boş bırakırsan sadece "Günaydın" yazar
const GUN = ["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"], AY = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"];
const selam = h => h < 6 ? "İyi geceler" : h < 12 ? "Günaydın" : h < 18 ? "İyi günler" : "İyi akşamlar";
export const render = () => {
  const d = new Date(), hh = String(d.getHours()).padStart(2, "0"), mm = String(d.getMinutes()).padStart(2, "0"), s = d.getSeconds();
  const R = 44, C = 2 * Math.PI * R, off = C * (1 - s / 60);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
      <svg width="104" height="104" viewBox="0 0 104 104">
        <circle cx="52" cy="52" r={R} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="6" />
        <circle cx="52" cy="52" r={R} fill="none" stroke="url(#g)" strokeWidth="6" strokeLinecap="round"
          strokeDasharray={C} strokeDashoffset={off} transform="rotate(-90 52 52)" style={{ transition: s === 0 ? "none" : "stroke-dashoffset 1s linear" }} />
        <defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stopColor="#60a5fa" /><stop offset="1" stopColor="#c084fc" /></linearGradient></defs>
        <text x="52" y="58" textAnchor="middle" fontSize="20" fontWeight="700" fill="#fff" fontFamily="-apple-system, Inter, sans-serif">{String(s).padStart(2, "0")}</text>
      </svg>
      <div>
        <div style={{ fontSize: 13, letterSpacing: 1.5, opacity: .7, textTransform: "uppercase" }}>{selam(d.getHours())}{AD ? ", " + AD : ""}</div>
        <div style={{ fontSize: 64, fontWeight: 800, lineHeight: 1, letterSpacing: -2, background: "linear-gradient(90deg,#fff,#c7d2fe)", WebkitBackgroundClip: "text", color: "transparent" }}>
          {hh}<span style={{ opacity: s % 2 ? .25 : 1 }}>:</span>{mm}
        </div>
        <div style={{ fontSize: 14, opacity: .75, marginTop: 6 }}>{GUN[d.getDay()]}, {d.getDate()} {AY[d.getMonth()]} {d.getFullYear()}</div>
      </div>
    </div>
  );
};
